#pragma once
#define RESOURCE "Graphics/"
#define STD_FONT "LexendMega-Regular.ttf"