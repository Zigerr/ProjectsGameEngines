﻿#include <SFML/Graphics.hpp>
#include <iostream>
#include <string.h>
#define RESOURCE "Graphics/"
#define STD_FONT "LexendMega-Regular.ttf"
/*
       transform 
           ↑
      guiElemment
           ↑                
   +-------+--------+
   |       |        |
button inputField progressBar  

IF _ Focus
*/
namespace gui {

    class transform;
    class guiElemment;

    class button;
    class inputField;
    class progressBar;

    class render;
    class styleSheet;
};



class gui::guiElemment{
    public:
        void update();

};

class gui::styleSheet{
public :

    class style {
    public:
        
        std::string fontName;
        sf::Font font;
        sf::Color bgColor;
        
        sf::Color textColor;
        unsigned int textSize;

        sf::Color borderColor;
        float borderWidth;

        sf::Vector2f padding;

    public:

        style() { ; }

        style(std::string fontname, sf::Color bgcolor,
            sf::Color textcolor, unsigned int textsize, sf::Color borderolor,
            float borderwidth, sf::Vector2f padding) :

            fontName(fontname),
            bgColor(bgcolor),
            textColor(textcolor),
            textSize(textsize),
            borderColor(borderolor),
            borderWidth(borderwidth),
            padding(padding)
        {
            this->font.loadFromFile(RESOURCE + fontName);
        }
    };
    enum
    {
        NONE, HOVER, CLICK
    };
    //NONE=0, HOVER=1, CLICK=2
    gui::styleSheet::style state[3];

    styleSheet(){
        
        state[NONE]  = gui::styleSheet::style("LexendMega-Regular.ttf", { 0,0,0,0 }, { 170,170,170 },30, { 170,170,170 }, 2, { 10,10 });

        state[HOVER] = gui::styleSheet::style("LexendMega-Regular.ttf", { 0,0,0,0 }, { 170,170,170 }, 30, { 190,190,190 }, 3, { 8,8 });

        state[CLICK] = gui::styleSheet::style("LexendMega-Regular.ttf", { 0,0,0,0 }, { 170,170,170 }, 30, { 60,70,120 }, 2, { 10,10 });
    }
};
//----------------------------------------------------------------------------------------------------------------------------------------
class gui::button : gui::guiElemment{
private:

    sf::Text _text;
    sf::RectangleShape _body;
    sf::RenderWindow *_window;

    sf::Vector2f _position;
    sf::Vector2f _rotation;
    sf::Vector2f _size;

    gui::styleSheet _states;
    
    void(*_OnClick)();

public :
    button();

    button(sf::Text *t, sf::RectangleShape *b) :_text(*t), _body(*b) {
        ;
    }

    button(sf::RenderWindow* w, sf::String s) :_window(w) {

        _text.setFont(_states.state[_states.NONE].font);
        _text.setString(s);
        
        setState(_states.state[0]);
    }

    void setPosition(sf::Vector2f pos) {
        _position = pos;
        _body.setPosition(_position);
        _text.setPosition(_position);   
    }

    gui::styleSheet& getStyle() {
        return _states;
    }

    void setFunOnClick( void(*func) () ) {
        _OnClick = func;
    }

    void updateState(sf::Event *event) {
        static bool LB;
        if (_body.getGlobalBounds().contains((sf::Vector2f)sf::Mouse::getPosition(*_window))) {
            setState(_states.state[_states.HOVER]);
            if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                LB = 1;
            }
            if (event->type == sf::Event::MouseButtonReleased) {
                if (LB == 1) {
                    LB = 0;
                    if (_OnClick != NULL)               
                    _OnClick();
                }
            }

        }
        else {
            setState(_states.state[_states.NONE]);
        }

    }

    void update(sf::Event *event) {
        updateState(event);
        _window->draw(_body);
        _window->draw(_text);
    }

private:

    void setState(gui::styleSheet::style st) {
        _body.setFillColor(st.bgColor);
        _body.setOutlineColor(st.borderColor);
        _body.setOutlineThickness(st.borderWidth);

        _text.setFillColor(st.textColor);
        _text.setCharacterSize(st.textSize);
        _body.setFillColor(st.bgColor);
        _body.setOutlineColor(st.borderColor);
        _body.setOutlineThickness(st.borderWidth);

        _body.setSize(sf::Vector2f(_text.getGlobalBounds().width + st.padding.x*2, _text.getGlobalBounds().height + st.padding.y*2));
        _body.setPosition(_text.getGlobalBounds().left - st.padding.x, _text.getGlobalBounds().top - st.padding.y);       
    }
};
//----------------------------------------------------------------------------------------------------------------------------------------
class gui::progressBar : gui::guiElemment {
private:
    sf::RectangleShape _body;
    sf::RectangleShape _border;

    sf::RenderWindow* _window;

    sf::Vector2f _position;
    sf::Vector2f _rotation;
    sf::Vector2f _size;


    float _progress;//0.0 ... 1.0

    void(*_OnLoad)();

    gui::styleSheet::style _st = { "LexendMega-Regular.ttf",{ 10,195,10 }, { 15,180,15 },30, { 170,170,170 }, 2, { 0,0 } };

public:
    progressBar(sf::RenderWindow* window,sf::RectangleShape body, sf::RectangleShape border):_body(body),_border(border), _window(window){
        ;
    }
    progressBar(sf::RenderWindow* window, sf::Vector2f position, sf::Vector2f size):_window(window) {
        setPosition(position);
        _size = size;
        _body.setSize(_size);
        _border.setSize(_size);
        
        _body.setFillColor(_st.bgColor);

        _border.setFillColor(sf::Color::Transparent);
        _border.setOutlineColor(_st.borderColor);
        _border.setOutlineThickness(_st.borderWidth);
    }
    void setPosition(sf::Vector2f pos) {
        _position = pos;
        _body.setPosition(_position);
        _border.setPosition(_position);
    }
    gui::styleSheet::style& getStyle() {
        return _st;
    }

    float getProgress()        {return _progress;}

    void setProgress(float pr) { _progress = pr; }
    void addProgress(float pr) {_progress += pr; }
    
    void setFunOnLoad(void(*onLoad)()) {
        _OnLoad = onLoad;
    }
    
    void update(sf::Event* event) {
        updateProgress();
        _window->draw(_body);
        _window->draw(_border);
    }
private:
    void updateProgress() {
        _body.setSize(_size);
        _border.setSize(_size);

        _body.setFillColor(_st.bgColor);

        _border.setFillColor(sf::Color::Transparent);
        _border.setOutlineColor(_st.borderColor);
        _border.setOutlineThickness(_st.borderWidth);

        if (_progress >= 0.0 && _progress <= 1.0) {
            _body.setSize(sf::Vector2f(_size.x * _progress, _size.y));
        }
        else if(_progress >=1.0){
            _OnLoad();
        _body.setSize(sf::Vector2f(_size.x, _size.y));
        }
    }
};
//----------------------------------------------------------------------------------------------------------------------------------------
class gui::inputField : gui::guiElemment{
private:

    sf::RectangleShape _body;
    sf::RectangleShape _cursor;
    sf::Text _text;
    sf::String _value;
   
    sf::RenderWindow* _window;
   
    sf::Vector2f _position;
    sf::Vector2f _rotation;
    unsigned int _length;
    unsigned int _sizeText;
    void(*_OnEnter)();

    gui::styleSheet _states;

    unsigned short int _tickVis;
    bool _focus;
public:
    inputField(sf::RenderWindow* window,sf::RectangleShape body,sf::Text text,sf::RectangleShape cursor):_window(window),_body(body),_text(text),_cursor(cursor){ ; }

    inputField(sf::RenderWindow* window,sf::Vector2f position, unsigned int length = 10,unsigned int sizeText = 30):_window(window),_position(position), _length(length), _sizeText(sizeText){
        _text.setFont(_states.state[_states.NONE].font);
        _states.state[0].textSize = _states.state[1].textSize = _states.state[2].textSize = sizeText;
        setPosition(_position);
    }

    void setPosition(sf::Vector2f pos) {
        _position = pos;
        _body.setPosition(_position);
        _text.setPosition(_position);
    }

    gui::styleSheet& getStyle() {
        return _states;
    }

    void setFunOnEnter(void(*func) ()) {
        _OnEnter = func;
    }

    void update(sf::Event* event) {
        updateState(event);
        _window->draw(_body);
        _window->draw(_text);
        _window->draw(_cursor);
    }

private:

    void updateState(sf::Event* event) {
        static bool LB;
        static int  r;
        static int lp=0;
        int s;
        if ((s = _value.getSize() - _length) >= 0) { lp = s; }
        if (_body.getGlobalBounds().contains((sf::Vector2f)sf::Mouse::getPosition(*_window))) {
            setState(_states.state[_states.HOVER]);
            if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                LB = 1;
            }
            if (event->type == sf::Event::MouseButtonReleased) {
                if (LB == 1) {
                    LB = 0;
                    _focus = 1;
                }
            }

        }
        else {
            setState(_states.state[_states.NONE]);
        }
        if (_focus) {
            setState(_states.state[2]);
            if (event->type == sf::Event::TextEntered) {
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::BackSpace) && r > 10) {

                    if (_value.getSize() >= 1) {//-------------------------------+
                        _value.erase(_value.getSize() - 1);//--------------------|= |  I thought but
                    if (lp > 0) { lp--; }//--------------------------------------|= | it s all what i can do(know)
                        _text.setString(_value.substring( lp , _length));//------+
                }
                     r = 0;
                }
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter) && r > 10) {
                    _focus = 0;
                    std::cout << (std::string)_value<<std::endl;
                    if(_OnEnter != NULL)
                        _OnEnter();
                }
                else {
                    if (r > 10) {
                        _value += event->text.unicode;
                        _text.setString(_value.substring(lp, _length+1));
                        r = 0;
                    }
                }
            }
        } 
        r++;
    }

    void setState(gui::styleSheet::style st) {
        _body.setFillColor(st.bgColor);
        _body.setOutlineColor(st.borderColor);
        _body.setOutlineThickness(st.borderWidth);

        _text.setFillColor(st.textColor);
        _text.setCharacterSize(st.textSize);

        _body.setFillColor(st.bgColor);
        _body.setOutlineColor(st.borderColor);
        _body.setOutlineThickness(st.borderWidth);

        _body.setSize(sf::Vector2f((_length-1) * _text.getCharacterSize() + st.padding.x * 2, _text.getCharacterSize()+_text.getGlobalBounds().height  - _text.getCharacterSize() + st.padding.y * 2));
        //_body.setPosition(_text.getGlobalBounds().left - st.padding.x, _text.getGlobalBounds().top - st.padding.y);
       
    }
};
void boo();
void load();
void bee();
sf::RenderWindow window(sf::VideoMode(500, 300, 1), "S GE е4.6х4W♥1");
gui::progressBar pb(&window,{ 50,200 }, { 200,40 });
int main() {
    
    window.setFramerateLimit(60);
    
    gui::button bt1(&window,"MuD of GoD");
    bt1.setPosition({ 200,100, });
    gui::button bt2(&window, "<-Right");
    bt2.getStyle().state[0].borderWidth = 0;
    bt2.getStyle().state[1].borderWidth = 0;
    bt2.getStyle().state[0].textColor = { 130,10,10 };
    bt2.getStyle().state[1].textColor = { 200,200,200 };
    bt1.getStyle().state[1].borderWidth = bt1.getStyle().state[0].borderWidth = 1;
    bt1.getStyle().state[1].borderColor = { 255, 205, 40 };
    bt1.getStyle().state[1].textColor = { 255, 176, 31 };
    bt1.getStyle().state[0].padding = bt1.getStyle().state[1].padding = { 20,10 };
    bt2.setFunOnClick(bee);
    bt1.setFunOnClick(boo);
    pb.setFunOnLoad(load);
    
    gui::inputField i1(&window, {120,50},8);

      
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
        }


        window.clear({32,32,32});
        bt1.update(&event);
        bt2.update(&event);
        pb.update(&event);
        i1.update(&event);
        window.display();
    }
    return 0;
}
void boo() {
    pb.addProgress(0.05f);
    //std::cout << pb.getProgress() << std::endl;
}
void bee() {
    pb.getStyle().bgColor += {10,10,10};
    pb.setProgress(0.0f);
    //std::cout << pb.getProgress() << std::endl;
}
void load() {
    pb.getStyle().bgColor += {10, 10, 10};

    std::cout << "\n +  / " << std::endl;
    std::cout << " \\ +" << std::endl;
    std::cout << "  \\  /" << std::endl;
    std::cout << "+---+" << std::endl;
    std::cout << "|   +-\\" << std::endl;
    std::cout << "|   |  | " << std::endl;
    std::cout << "+---/-+ " << std::endl;
    pb.setProgress(0.0f);

}